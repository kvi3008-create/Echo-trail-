Upload these files to your GitHub repo 'echo-trail' and enable GitHub Pages.
